# Final Report: Boxing Training Hub

## Project Overview

Boxing Training Hub is a multi-page website created for the CS430 final group project. The website presents boxing as a hobby and training activity. It explains basic boxing topics such as footwork, heavy bag practice, defense, discipline, and fitness.

The purpose of the project is to demonstrate the use of semantic HTML, external CSS, JavaScript interactivity, multimedia, responsive design, and GitHub Pages deployment.

## Design Process

The design process started by choosing a topic that is easy to understand and explain. Boxing was selected because it includes clear sections, visuals, and interactive ideas.

The website was planned with three pages:

- Home
- About
- Contact

The layout uses a header, navigation bar, main content sections, article cards, and footer. The design uses dark red, black, white, and light gray colors to match the boxing theme while keeping the content readable.

## Wireframes

The planned wireframe for the home page includes:

- Header at the top
- Navigation menu under the header
- Hero section with text and image
- Training focus cards
- Video section
- Footer at the bottom

The about page includes content sections explaining the purpose, design process, and technologies used.

The contact page includes a form with name, email, and message fields.

## Technologies Used

The project uses:

- HTML5 for structure
- CSS3 for styling and responsive design
- JavaScript for interactivity
- GitHub for version control
- GitHub Pages for live website deployment

## Key Features

The website includes several required features:

- Semantic HTML elements such as header, nav, section, article, main, and footer
- External CSS file inside the css folder
- Responsive design using Flexbox and CSS Grid
- JavaScript DOM manipulation
- JavaScript event handling
- Contact form validation
- Multimedia elements including an image and embedded YouTube iframe
- Multiple pages including index.html, about.html, and contact.html

## Challenges Faced

One challenge was organizing the project into the correct folder structure. This was solved by creating separate folders for CSS, JavaScript, images, and documentation.

Another challenge was making sure the JavaScript worked on different pages. This was solved by checking if elements exist before adding event listeners.

A third challenge was making the website responsive. This was solved by using Flexbox, CSS Grid, and a media query for smaller screens.

## How GitHub Was Used

GitHub was used to store the project files in a public repository. The files were uploaded into the correct structure, including HTML files, css folder, js folder, images folder, README.md, and docs folder.

GitHub Pages was used to publish the website live. After enabling GitHub Pages, the project became available through a public URL.

## Individual Contributions

Mohammad worked on the website topic, HTML structure, CSS styling, JavaScript interactivity, contact form validation, project documentation, and final presentation preparation.

If this is a group project, each member should add their own contribution here.

## References

- W3C HTML Validator: https://validator.w3.org/
- MDN Web Docs HTML: https://developer.mozilla.org/en-US/docs/Web/HTML
- MDN Web Docs CSS: https://developer.mozilla.org/en-US/docs/Web/CSS
- MDN Web Docs JavaScript: https://developer.mozilla.org/en-US/docs/Web/JavaScript
- GitHub Pages Documentation: https://docs.github.com/en/pages
