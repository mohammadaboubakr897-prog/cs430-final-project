const motivationButton = document.getElementById("motivation-button");
const motivationText = document.getElementById("motivation-text");

if (motivationButton) {
    motivationButton.addEventListener("click", function () {
        motivationText.textContent = "Discipline beats motivation. Keep training one round at a time.";
    });
}

const contactForm = document.getElementById("contact-form");
const formMessage = document.getElementById("form-message");

if (contactForm) {
    contactForm.addEventListener("submit", function (event) {
        event.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const message = document.getElementById("message").value.trim();

        if (name === "" || email === "" || message === "") {
            formMessage.textContent = "Please fill out all fields before submitting.";
            formMessage.style.color = "red";
        } else {
            formMessage.textContent = "Thank you! Your message was submitted successfully.";
            formMessage.style.color = "green";
            contactForm.reset();
        }
    });
}
